const imagenComida = document.getElementById('imagencomida');

const imagenOriginal = 'static/images/images.jpg';
const imagenNueva = 'static/images/libros.jpg';

imagenComida.addEventListener('mouseenter', function() {
    imagenComida.src = imagenNueva;
});

imagenComida.addEventListener('mouseleave', function() {
    imagenComida.src = imagenOriginal;
});